## Device Configuration for Xiaomi Redmi 10/10C/10 Power

The Xiaomi Redmi 10/10C/10 Power (codenamed _"fog/rain/wind"_) is a low range smartphone from Xiaomi.

Redmi 10C was announced and released in March 2022.
